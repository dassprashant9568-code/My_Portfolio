export interface Education {
  institution: string;
  degree: string;
  period: string;
  location?: string;
}

export interface Certification {
  name: string;
  issuer?: string;
  year?: string;
}

export interface Skill {
  name: string;
  category: 'Technical' | 'Tools' | 'Concepts';
  level: number; // 0-100
}

export interface Project {
  title: string;
  description: string;
  technologies: string[];
  link?: string;
  image?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface ContactInfo {
  email: string;
  linkedin: string;
  github?: string;
  location: string;
  resume?: string;
}