import React, { useState, useEffect } from 'react';
import { 
  Github, 
  Linkedin, 
  Mail, 
  MapPin, 
  ExternalLink,
  Award,
  BookOpen,
  Code,
  Briefcase,
  Layers
} from 'lucide-react';
import { PERSONAL_INFO, CONTACT_INFO, EDUCATION, CERTIFICATIONS, SKILLS, PROJECTS } from './constants';
import ChatWidget from './components/ChatWidget';
import SkillsChart from './components/SkillsChart';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState('home');

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'skills', 'projects', 'education', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element && element.offsetTop <= scrollPosition && (element.offsetTop + element.offsetHeight) > scrollPosition) {
          setActiveSection(section);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0 font-bold text-xl text-slate-800 dark:text-white">
              PKD<span className="text-blue-600">.</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                {['Home', 'About', 'Skills', 'Projects', 'Education', 'Contact'].map((item) => (
                  <button
                    key={item}
                    onClick={() => scrollToSection(item.toLowerCase())}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeSection === item.toLowerCase()
                        ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-slate-800'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            {/* Mobile menu button could go here */}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-12 sm:pt-32 sm:pb-20 lg:pb-32 px-4 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-in slide-in-from-left duration-700">
            <div className="space-y-4">
              <div className="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 text-sm font-medium">
                Available for opportunities
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                {PERSONAL_INFO.name}
              </h1>
              <h2 className="text-2xl sm:text-3xl text-slate-600 dark:text-slate-300 font-medium">
                {PERSONAL_INFO.title}
              </h2>
              <p className="text-lg text-slate-600 dark:text-slate-400 max-w-xl leading-relaxed">
                {PERSONAL_INFO.tagline}
              </p>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <a 
                href="mailto:dassprashant9568@gmail.com"
                className="px-6 py-3 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-medium shadow-lg hover:shadow-blue-500/25 transition-all flex items-center gap-2 cursor-pointer z-10"
              >
                <Mail size={18} />
                Contact Me
              </a>
              <a 
                href={CONTACT_INFO.linkedin}
                target="_blank"
                rel="noreferrer"
                className="px-6 py-3 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 font-medium shadow-sm transition-all flex items-center gap-2"
              >
                <Linkedin size={18} />
                LinkedIn
              </a>
              {CONTACT_INFO.github && (
                <a 
                  href={CONTACT_INFO.github}
                  target="_blank"
                  rel="noreferrer"
                  className="px-6 py-3 rounded-full bg-gray-900 hover:bg-gray-800 dark:bg-gray-700 dark:hover:bg-gray-600 text-white font-medium shadow-sm transition-all flex items-center gap-2"
                >
                  <Github size={18} />
                  GitHub
                </a>
              )}
            </div>

            <div className="flex items-center gap-4 text-slate-500 dark:text-slate-400 text-sm">
              <span className="flex items-center gap-1">
                <MapPin size={16} />
                {CONTACT_INFO.location}
              </span>
            </div>
          </div>

          <div className="relative animate-in slide-in-from-right duration-700 hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-full blur-3xl opacity-20"></div>
            <div className="relative bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-700 p-8">
              <div className="flex items-center gap-4 mb-6 border-b border-slate-100 dark:border-slate-700 pb-4">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/50 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <Code size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg dark:text-white">Core Competencies</h3>
                  <p className="text-sm text-slate-500">Data Analytics Stack</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {SKILLS.slice(0, 6).map((skill) => (
                  <div key={skill.name} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                    <span className="font-medium text-slate-700 dark:text-slate-200">{skill.name}</span>
                    <span className="text-xs font-bold text-blue-600 bg-blue-100 dark:bg-blue-900/50 px-2 py-1 rounded">
                      {skill.level}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white dark:bg-slate-800 border-y border-slate-100 dark:border-slate-800">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">About Me</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
          </div>
          <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed text-center">
            {PERSONAL_INFO.about}
          </p>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-slate-50 dark:bg-slate-700/30 rounded-2xl text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase size={24} />
              </div>
              <h3 className="font-bold text-slate-900 dark:text-white mb-2">Professional</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Dedicated to professional growth and delivering business value through data.</p>
            </div>
            <div className="p-6 bg-slate-50 dark:bg-slate-700/30 rounded-2xl text-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Code size={24} />
              </div>
              <h3 className="font-bold text-slate-900 dark:text-white mb-2">Technical</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Proficient in Python, SQL, and modern BI tools like Tableau and Power BI.</p>
            </div>
            <div className="p-6 bg-slate-50 dark:bg-slate-700/30 rounded-2xl text-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/50 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award size={24} />
              </div>
              <h3 className="font-bold text-slate-900 dark:text-white mb-2">Certified</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Continuously upskilling with certifications in Data Analytics and BI.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">Skills & Expertise</h2>
              <div className="w-20 h-1 bg-blue-600 rounded-full"></div>
            </div>
            <p className="text-slate-600 dark:text-slate-400 mb-8">
              I bring a comprehensive toolkit for data analysis, from data wrangling and database management to advanced visualization and reporting.
            </p>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Technical Languages</h3>
                <div className="flex flex-wrap gap-2">
                  {SKILLS.filter(s => s.category === 'Technical').map(s => (
                    <span key={s.name} className="px-3 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full text-sm font-medium border border-blue-100 dark:border-blue-800">
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">BI Tools & Software</h3>
                <div className="flex flex-wrap gap-2">
                  {SKILLS.filter(s => s.category === 'Tools').map(s => (
                    <span key={s.name} className="px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 rounded-full text-sm font-medium border border-emerald-100 dark:border-emerald-800">
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Concepts</h3>
                <div className="flex flex-wrap gap-2">
                  {SKILLS.filter(s => s.category === 'Concepts').map(s => (
                    <span key={s.name} className="px-3 py-1 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 rounded-full text-sm font-medium border border-purple-100 dark:border-purple-800">
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div>
            <SkillsChart />
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-slate-50 dark:bg-slate-800/30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">Featured Projects</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
            <p className="mt-4 text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              A showcase of practical work and simulations demonstrating my ability to solve real-world data problems.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {PROJECTS.map((project, index) => (
              <div key={index} className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg border border-slate-100 dark:border-slate-700 hover:shadow-xl transition-all duration-300 flex flex-col group">
                {/* Project Image */}
                <div className="h-48 overflow-hidden relative">
                  {project.link ? (
                    <a href={project.link} target="_blank" rel="noopener noreferrer" className="block h-full w-full cursor-pointer">
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent z-10 transition-opacity"></div>
                        <img 
                            src={project.image || "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop"} 
                            alt={project.title}
                            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                        />
                         <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20 bg-black/40">
                             <div className="bg-white/20 backdrop-blur-md p-3 rounded-full border border-white/30 text-white">
                                <ExternalLink size={24} />
                             </div>
                         </div>
                        <div className="absolute bottom-4 left-4 z-20">
                             <span className="inline-block px-2 py-1 rounded-md bg-white/20 backdrop-blur-md text-xs font-semibold text-white border border-white/30">
                                Analytics
                             </span>
                        </div>
                    </a>
                  ) : (
                    <>
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent z-10"></div>
                        <img 
                            src={project.image || "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop"} 
                            alt={project.title}
                            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute bottom-4 left-4 z-20">
                             <span className="inline-block px-2 py-1 rounded-md bg-white/20 backdrop-blur-md text-xs font-semibold text-white border border-white/30">
                                Analytics
                             </span>
                        </div>
                    </>
                  )}
                </div>
                
                <div className="p-8 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-3">
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                        {project.link ? (
                            <a href={project.link} target="_blank" rel="noopener noreferrer" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                                {project.title}
                            </a>
                        ) : (
                            project.title
                        )}
                      </h3>
                      {project.link && (
                          <a href={project.link} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors flex-shrink-0 ml-2 mt-1">
                              <ExternalLink size={20} />
                          </a>
                      )}
                  </div>
                  
                  <p className="text-slate-600 dark:text-slate-300 mb-6 leading-relaxed flex-grow">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mt-auto">
                    {project.technologies.map((tech) => (
                      <span key={tech} className="px-3 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-semibold rounded-full">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Education & Certifications */}
      <section id="education" className="py-20 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">Education & Certifications</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Education Column */}
            <div className="space-y-6">
              <h3 className="flex items-center gap-2 text-xl font-bold text-slate-800 dark:text-white mb-6">
                <BookOpen className="text-blue-600" />
                Education
              </h3>
              {EDUCATION.map((edu, index) => (
                <div key={index} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 transition-hover hover:shadow-md">
                  <h4 className="font-bold text-slate-900 dark:text-white text-lg">{edu.degree}</h4>
                  <p className="text-blue-600 dark:text-blue-400 font-medium">{edu.institution}</p>
                  <div className="flex justify-between items-center mt-4 text-sm text-slate-500 dark:text-slate-400">
                    <span>{edu.period}</span>
                    {edu.location && <span>{edu.location}</span>}
                  </div>
                </div>
              ))}
            </div>

            {/* Certifications Column */}
            <div className="space-y-6">
              <h3 className="flex items-center gap-2 text-xl font-bold text-slate-800 dark:text-white mb-6">
                <Award className="text-blue-600" />
                Certifications
              </h3>
              {CERTIFICATIONS.map((cert, index) => (
                <div key={index} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 transition-hover hover:shadow-md">
                  <h4 className="font-bold text-slate-900 dark:text-white text-lg">{cert.name}</h4>
                  <p className="text-slate-600 dark:text-slate-300 mt-1">{cert.issuer}</p>
                  <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 dark:text-emerald-400 px-2 py-1 rounded">
                      Completed
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6">Let's Connect</h2>
        <p className="text-slate-600 dark:text-slate-400 mb-10 text-lg">
          I'm currently looking for new opportunities as a Data Analyst. Whether you have a question or just want to say hi, I'll try my best to get back to you!
        </p>
        
        <div className="flex flex-col md:flex-row justify-center gap-6">
          <a 
            href="mailto:dassprashant9568@gmail.com"
            className="flex items-center justify-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all shadow-lg hover:shadow-blue-500/25"
          >
            <Mail size={20} />
            <div className="text-left">
              <div className="text-xs opacity-80">Email me at</div>
              <div className="font-semibold">{CONTACT_INFO.email}</div>
            </div>
          </a>

          <a 
            href={CONTACT_INFO.linkedin}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-3 px-8 py-4 bg-slate-800 text-white rounded-xl hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 transition-all shadow-lg"
          >
            <Linkedin size={20} />
            <div className="text-left">
              <div className="text-xs opacity-80">Connect on</div>
              <div className="font-semibold">LinkedIn</div>
            </div>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} Prashant Kumar Dass. All rights reserved.
          </p>
        </div>
      </footer>

      {/* AI Chat Widget */}
      <ChatWidget />
    </div>
  );
};

export default App;