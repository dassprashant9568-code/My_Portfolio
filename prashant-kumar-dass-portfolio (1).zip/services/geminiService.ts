import { GoogleGenAI } from "@google/genai";
import { RESUME_CONTEXT } from '../constants';

const apiKey = process.env.API_KEY;

// Initialize the Gemini API client safely
const createClient = () => {
  if (!apiKey) {
    console.error("API_KEY is missing from environment variables.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

const ai = createClient();

export const sendChatMessage = async (
  message: string, 
  history: { role: 'user' | 'model'; parts: { text: string }[] }[]
): Promise<string> => {
  if (!ai) {
    return "I'm sorry, I cannot connect to the AI service right now. Please check the API configuration.";
  }

  try {
    const model = ai.models;
    
    // Construct the chat history with system context for the first turn if possible, 
    // or just pass context in the system instruction config.
    const chatSession = ai.chats.create({
        model: "gemini-2.5-flash",
        config: {
            systemInstruction: RESUME_CONTEXT,
        },
        history: history
    });

    const result = await chatSession.sendMessage({
      message: message
    });

    return result.text || "I didn't get a response. Please try again.";
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    return "Something went wrong while thinking. Please try again later.";
  }
};
