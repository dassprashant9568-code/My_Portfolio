import { Education, Certification, Skill, ContactInfo, Project } from './types';

export const PERSONAL_INFO = {
  name: "Prashant Kumar Dass",
  title: "Data Analyst",
  tagline: "Turning raw data into actionable insights with Python, Power BI, and SQL.",
  about: "I am a driven Data Analyst based in Agra, Uttar Pradesh, with a strong foundation in data visualization and business intelligence. My expertise spans the entire data lifecycle, from extraction and cleaning using SQL and Pandas to creating impactful dashboards in Power BI and Tableau. I am passionate about uncovering trends that drive business growth.",
};

export const CONTACT_INFO: ContactInfo = {
  email: "dassprashant9568@gmail.com",
  linkedin: "https://www.linkedin.com/in/prashant-kumar-dass-a6a0b0204",
  github: "https://github.com/dassprashant9568-code",
  location: "Agra, Uttar Pradesh, India",
  resume: "/Prashant_Kumar_Dass_Resume.pdf"
};

export const EDUCATION: Education[] = [
  {
    institution: "Dr. Bhimrao Ambedkar University (DBRAU), Agra",
    degree: "Bachelor of Science",
    period: "January 2021 - January 2024",
    location: "Agra, India"
  },
  {
    institution: "Eshan Group Of Institutions",
    degree: "Diploma of Education, Mechanical Engineering",
    period: "2018 - 2021",
    location: "Agra, India"
  }
];

export const CERTIFICATIONS: Certification[] = [
  {
    name: "Data Analytics Job Simulation",
    issuer: "Forage",
  },
  {
    name: "Business & Data Analytics Specialisation",
    issuer: "Nano Degree Program",
  }
];

export const PROJECTS: Project[] = [
  {
    title: "Predictive Health Analytics: Risk Factor Identification",
    description: "Conducted exploratory analysis on health insurance data to segment adult client bases and identify key cost drivers. Utilized multivariate analysis to uncover correlations between smoker status, BMI, and insurance charges, providing actionable insights for resource allocation.",
    technologies: ["Python", "Pandas", "Seaborn", "Matplotlib", "NumPy"],
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=800&auto=format&fit=crop",
    link: "https://www.kaggle.com/code/prashantdass/heart-health-disease-project"
  },
  {
    title: "Predictive Hotel Analytics: Revenue & Cancellations",
    description: "Analyzed a large dataset of hotel bookings to understand demand and reduce cancellation rates. Discovered significant correlations between lead time and cancellation probability, enabling better revenue optimization and operational planning.",
    technologies: ["Python", "Pandas", "Seaborn", "Matplotlib", "NumPy"],
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800&auto=format&fit=crop",
    link: "https://www.kaggle.com/code/prashantdass/hotel-booking-analysis"
  },
  {
    title: "Sales Performance Dashboard in Power BI",
    description: "Designed an interactive dashboard using Power BI to track key sales metrics like Total Sales, Profit, and Ship Time. Insights revealed high-revenue product categories (Bikes) and profitability trends by demographic, facilitating data-driven decision-making.",
    technologies: ["Power BI", "DAX", "Power Query", "Business Intelligence"],
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=800&auto=format&fit=crop"
  },
  {
    title: "Exploratory Data Analysis on Google Play Store Apps",
    description: "Performed in-depth EDA using Python to uncover patterns in app ratings, installs, and pricing across categories. Handled data cleaning and visualization to reveal insights on category popularity and user sentiment for app developers.",
    technologies: ["Python", "Pandas", "SQL", "Matplotlib", "Seaborn"],
    image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=800&auto=format&fit=crop",
    link: "https://www.kaggle.com/code/prashantdass/analysis-on-google-play-store-apps-data"
  },
  {
    title: "Hospital Readmission Analysis (Excel & Pivot Tables)",
    description: "Analyzed hospital readmission patterns using Excel Pivot Tables. Standardized raw data to identify high-risk patient segments and age groups, uncovering correlations between emergency visits and readmission likelihood to improve patient follow-up.",
    technologies: ["Excel", "Pivot Tables", "Conditional Formatting", "Data Cleaning"],
    image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=800&auto=format&fit=crop"
  }
];

export const SKILLS: Skill[] = [
  { name: "Python", category: "Technical", level: 85 },
  { name: "SQL", category: "Technical", level: 80 },
  { name: "Pandas", category: "Technical", level: 85 },
  { name: "NumPy", category: "Technical", level: 80 },
  { name: "Microsoft Power Query", category: "Technical", level: 75 },
  { name: "Power BI", category: "Tools", level: 90 },
  { name: "Tableau", category: "Tools", level: 75 },
  { name: "Excel", category: "Tools", level: 85 },
  { name: "Conditional Formatting", category: "Tools", level: 85 },
  { name: "Business Intelligence (BI)", category: "Concepts", level: 80 },
];

export const RESUME_CONTEXT = `
You are an AI assistant representing Prashant Kumar Dass on his portfolio website.
Here is his resume context:
Name: ${PERSONAL_INFO.name}
Role: ${PERSONAL_INFO.title}
Location: ${CONTACT_INFO.location}
Email: ${CONTACT_INFO.email}
LinkedIn: ${CONTACT_INFO.linkedin}
GitHub: ${CONTACT_INFO.github}

Summary: ${PERSONAL_INFO.about}

Top Skills: Business Intelligence (BI), Microsoft Power Query, Pandas, NumPy, Python, SQL, Tableau, Excel, Conditional Formatting.

Projects:
${PROJECTS.map(p => `- ${p.title}: ${p.description} (Tools: ${p.technologies.join(', ')})`).join('\n')}

Education:
1. Bachelor of Science from Dr. Bhimrao Ambedkar University (DBRAU), Agra (2021-2024).
2. Diploma of Education, Mechanical Engineering from Eshan Group Of Institutions (2018-2021).

Certifications:
1. Data Analytics Job Simulation.
2. Business & Data analytics specialisation nano degree program.

Answer questions as if you are Prashant or a helpful recruiter assistant. Keep answers concise and professional.
`;